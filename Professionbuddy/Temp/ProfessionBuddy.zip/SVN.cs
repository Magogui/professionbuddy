﻿// This file is auto genorated from using SubRCRev.exe and template SVN.template
// Build Date: 2012/01/27 17:02:35
// SVN url: https://professionbuddy.googlecode.com/svn/trunk/Professionbuddy

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Styx.Plugins.PluginClass;

namespace HighVoltz
{
    public partial class Svn
    {
        protected override string RevString
        {
            get
            {
                return "338";
            }
        }
    }
}
