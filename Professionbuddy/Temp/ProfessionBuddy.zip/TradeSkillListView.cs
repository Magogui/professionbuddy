﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Drawing;

namespace HighVoltz
{
    public class TradeSkillListView : TabPage
    {
        public DataGridViewTextBoxColumn NameColumn { get; private set; }
        public DataGridViewTextBoxColumn CraftableColumn { get; private set; }
        public DataGridViewTextBoxColumn DifficultyColumn { get; private set; }
        public DataGridView TradeDataView { get; private set; }
        public TextBox FilterText { get; private set; }
        public ComboBox CategoryCombo { get; private set; }
        private TableLayoutPanel tabTableLayout;

        public TradeSkillListView()
            : this(0)
        {
        }

        public int TradeIndex
        {
            get { return index; }
        }

        private int index; // index to Professionbuddy.Instance.TradeSkillList

        public TradeSkillListView(int index)
        {
            this.index = index;
            // Filter TextBox
            FilterText = new TextBox();
            FilterText.Dock = DockStyle.Fill;
            // Category Combobox
            CategoryCombo = new ComboBox();
            CategoryCombo.Dock = DockStyle.Fill;
            // columns
            NameColumn = new DataGridViewTextBoxColumn();
            CraftableColumn = new DataGridViewTextBoxColumn();
            DifficultyColumn = new DataGridViewTextBoxColumn();
            NameColumn.HeaderText = "Name";
            CraftableColumn.HeaderText = "#";
            NameColumn.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            CraftableColumn.MinimumWidth = 25;
            CraftableColumn.Width = 25;
            DifficultyColumn.MinimumWidth = 25;
            DifficultyColumn.Width = 25;
            // DataGridView
            TradeDataView = new DataGridView();
            TradeDataView.Dock = DockStyle.Fill;
            TradeDataView.AllowUserToAddRows = false;
            TradeDataView.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            TradeDataView.RowHeadersVisible = false;
            TradeDataView.Columns.Add(NameColumn);
            TradeDataView.Columns.Add(CraftableColumn);
            TradeDataView.Columns.Add(DifficultyColumn);
            TradeDataView.AllowUserToResizeRows = false;
            TradeDataView.EditMode = DataGridViewEditMode.EditProgrammatically;
            TradeDataView.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            TradeDataView.ColumnHeadersHeight = 21;
            TradeDataView.RowTemplate.Height = 16;
            //table layout
            tabTableLayout = new TableLayoutPanel();
            tabTableLayout.ColumnCount = 2;
            tabTableLayout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tabTableLayout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tabTableLayout.RowCount = 2;
            tabTableLayout.RowStyles.Add(new RowStyle(SizeType.Absolute, 30F));
            tabTableLayout.RowStyles.Add(new RowStyle(SizeType.Percent, 50F));
            tabTableLayout.Controls.Add(FilterText, 0, 0);
            tabTableLayout.Controls.Add(CategoryCombo, 1, 0);
            tabTableLayout.Controls.Add(TradeDataView, 0, 1);
            tabTableLayout.Dock = DockStyle.Fill;
            tabTableLayout.SetColumnSpan(TradeDataView, 2);
            // tab
            this.Controls.Add(tabTableLayout);
            this.Text = Professionbuddy.Instance.TradeSkillList[index].Name;
            // populate the controls with data
            CategoryCombo.Items.Add(""); // blank line will show all headers...

            foreach (KeyValuePair<uint, Recipe> kv in Professionbuddy.Instance.TradeSkillList[index].Recipes)
            {
                if (!CategoryCombo.Items.Contains(kv.Value.Header))
                {
                    CategoryCombo.Items.Add(kv.Value.Header);
                }
                TradeDataView.Rows.Add(new TradeSkillRecipeCell(index, kv.Key), Util.CalculateRecipeRepeat(kv.Value),
                                       (int)kv.Value.Difficulty); // make color column sortable by dificulty..
            }
            TradeDataView_SelectionChanged(null, null);
            // hook events
            FilterText.TextChanged += new EventHandler(FilterText_TextChanged);
            CategoryCombo.SelectedValueChanged += new EventHandler(SectionCombo_SelectedValueChanged);
            TradeDataView.SelectionChanged += new EventHandler(TradeDataView_SelectionChanged);
            TradeDataView.CellFormatting += new DataGridViewCellFormattingEventHandler(TradeDataView_CellFormatting);
        }

        private void TradeDataView_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {

            if (TradeDataView.Columns[e.ColumnIndex].HeaderText == "")
            {
                TradeSkillRecipeCell tsrc = TradeDataView.Rows[e.RowIndex].Cells[0].Value as TradeSkillRecipeCell;
                e.CellStyle.ForeColor = tsrc.Recipe.Color;
                e.CellStyle.BackColor = e.CellStyle.ForeColor;
                e.CellStyle.SelectionBackColor = e.CellStyle.ForeColor;
                e.CellStyle.SelectionForeColor = e.CellStyle.ForeColor;
            }
        }

        private void TradeDataView_SelectionChanged(object sender, EventArgs e)
        {
            if (MainForm.IsValid)
            {
                MainForm.Instance.IngredientsView.Rows.Clear();
                if (TradeDataView.SelectedRows.Count > 0)
                {
                    TradeSkillRecipeCell cell = (TradeSkillRecipeCell)TradeDataView.SelectedRows[0].Cells[0].Value;
                    Recipe _recipe = Professionbuddy.Instance.TradeSkillList[index].Recipes[cell.RecipeID];
                    DataGridViewRow row = new DataGridViewRow();
                    foreach (Ingredient ingred in _recipe.Ingredients)
                    {
                        uint inBags = ingred.InBagItemCount;
                        MainForm.Instance.IngredientsView.Rows.
                            Add(ingred.Name, ingred.Required, inBags);
                        if (ingred.InBagItemCount < ingred.Required)
                        {
                            MainForm.Instance.IngredientsView.Rows[MainForm.Instance.IngredientsView.Rows.Count - 1].
                                Cells[2].Style.SelectionBackColor = Color.Red;
                            MainForm.Instance.IngredientsView.Rows[MainForm.Instance.IngredientsView.Rows.Count - 1].
                                Cells[2].Style.ForeColor = Color.Red;
                        }
                        MainForm.Instance.IngredientsView.ClearSelection();
                    }
                }
            }
        }

        private void FilterText_TextChanged(object sender, EventArgs e)
        {
            filterTradeDateView();
        }

        private void SectionCombo_SelectedValueChanged(object sender, EventArgs e)
        {
            filterTradeDateView();
        }

        private void filterTradeDateView()
        {
            TradeDataView.Rows.Clear();
            string filter = FilterText.Text.ToUpper();
            bool noFilter = string.IsNullOrEmpty(FilterText.Text);
            bool showAllCategories = string.IsNullOrEmpty(CategoryCombo.Text);
            foreach (KeyValuePair<uint, Recipe> kv in Professionbuddy.Instance.TradeSkillList[index].Recipes)
            {
                if ((noFilter || kv.Value.Name.ToUpper().Contains(filter)) &&
                    (showAllCategories || kv.Value.Header == CategoryCombo.Text))
                {
                    TradeDataView.Rows.Add(new TradeSkillRecipeCell(index, kv.Key), kv.Value.CanRepeatNum,
                                           kv.Value.Color);
                }
            }
        }
    }

    // attached to the TradeSkillListView cell values

    internal class TradeSkillRecipeCell
    {
        public TradeSkillRecipeCell(int index, uint id)
        {
            TradeSkillIndex = index;
            RecipeID = id;
        }

        public string RecipeName
        {
            get { return Professionbuddy.Instance.TradeSkillList[TradeSkillIndex].Recipes[RecipeID].Name; }
        }

        public uint RecipeID { get; private set; }

        public Recipe Recipe
        {
            get { return Professionbuddy.Instance.TradeSkillList[TradeSkillIndex].Recipes[RecipeID]; }
        }

        public int TradeSkillIndex { get; private set; }

        public override string ToString()
        {
            return RecipeName;
        }
    }
}
